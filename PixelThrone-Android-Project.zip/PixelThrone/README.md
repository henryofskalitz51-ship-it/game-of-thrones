# تاج‌وتخت پیکسلی — پروژه اندروید

گزینه ۱ (Android Studio): پوشه را باز کنید و Build > Build APK(s) را بزنید.
خروجی: app/build/outputs/apk/debug/app-debug.apk

گزینه ۲ (بدون نصب چیزی): پوشه را در یک ریپوی GitHub آپلود کنید، در تب Actions اجرای Build APK را باز کنید و فایل app-debug.apk را از Artifacts بگیرید.
